﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using BusinessEntity;

namespace BusinessLogicLayer
{
    public class Bldakhl
    {
        public string Create(Dakhl dakhl)
        {
            Dldakhl dldakhl = new Dldakhl();
            return dldakhl.Create(dakhl);

        }

        public List<Dakhl> ReadDakhl()
        {
            Dldakhl dldakhl2 = new Dldakhl();
            List<Dakhl> dakhllist2 = dldakhl2.ReadDakhl();

            return dakhllist2;
        }

    }




    public class Blkharj
    {
        public string Create(Kharj kharj)
        {
            Dlkharj dlkharj = new Dlkharj();
            return dlkharj.Create(kharj);

        }

        public List<Kharj> Readkharj()
        {
            Dlkharj dlkharj2 = new Dlkharj();
            List<Kharj> kharjlist2 = dlkharj2.ReadKharj();

            return kharjlist2;
        }
    }



    public class Blentitydakhl
    {
        public string Create(EntityDakhl entitydakhl)
        {
            Dlentitydakhl dlentitydakhl = new Dlentitydakhl();
            return dlentitydakhl.Create(entitydakhl);

        }

        public List<EntityDakhl> Readentitydakhl()
        {
            Dlentitydakhl dlentitydakhl2 = new Dlentitydakhl();
            List<EntityDakhl> entitydakhllist2 = dlentitydakhl2.Readentitydakhl();

            return entitydakhllist2;
        }

    }



    public class Blentitykharj
    {
        public string Create(EntityKharj entitykharj)
        {
            Dlentitykharj dlentitykharj = new Dlentitykharj();
            return dlentitykharj.Create(entitykharj);

        }

        public List<EntityKharj> Readentitykharj()
        {
            Dlentitykharj dlentitykharj2 = new Dlentitykharj();
            List<EntityKharj> entitykharjlist2 = dlentitykharj2.Readentitykharj();

            return entitykharjlist2;
        }

    }


}
