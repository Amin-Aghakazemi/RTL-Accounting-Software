﻿
namespace Hesabema
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridViewDakhl = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.comboBoxDakhl = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxAmountDakhl = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPriceDakhl = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonSaveDakhl = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.dataGridViewKharj = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.comboBoxKharj = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxAmountKharj = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxPriceKharj = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.buttonSaveKharj = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridViewDakhlGozaresh = new System.Windows.Forms.DataGridView();
            this.dataGridViewKharjGozaresh = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.buttonNamayeshGozaresh = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.maskedTextBoxStartDate = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.maskedTextBoxEndDate = new System.Windows.Forms.MaskedTextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label21 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonAddAghlamDakh = new System.Windows.Forms.Button();
            this.textBoxAddAghlamDakh = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label22 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxAddAghlamKharj = new System.Windows.Forms.TextBox();
            this.buttonAddAghlamKharj = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelAmoozesh = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDakhl)).BeginInit();
            this.panel8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKharj)).BeginInit();
            this.panel10.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDakhlGozaresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKharjGozaresh)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel9);
            this.tabPage1.Controls.Add(this.panel8);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.dataGridViewDakhl);
            this.panel9.Controls.Add(this.label1);
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Name = "panel9";
            // 
            // dataGridViewDakhl
            // 
            this.dataGridViewDakhl.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDakhl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewDakhl, "dataGridViewDakhl");
            this.dataGridViewDakhl.Name = "dataGridViewDakhl";
            this.dataGridViewDakhl.ReadOnly = true;
            this.dataGridViewDakhl.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.comboBoxDakhl);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.textBoxAmountDakhl);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.textBoxPriceDakhl);
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.buttonSaveDakhl);
            resources.ApplyResources(this.panel8, "panel8");
            this.panel8.Name = "panel8";
            // 
            // comboBoxDakhl
            // 
            this.comboBoxDakhl.DropDownHeight = 250;
            resources.ApplyResources(this.comboBoxDakhl, "comboBoxDakhl");
            this.comboBoxDakhl.FormattingEnabled = true;
            this.comboBoxDakhl.Items.AddRange(new object[] {
            resources.GetString("comboBoxDakhl.Items"),
            resources.GetString("comboBoxDakhl.Items1"),
            resources.GetString("comboBoxDakhl.Items2"),
            resources.GetString("comboBoxDakhl.Items3"),
            resources.GetString("comboBoxDakhl.Items4"),
            resources.GetString("comboBoxDakhl.Items5"),
            resources.GetString("comboBoxDakhl.Items6"),
            resources.GetString("comboBoxDakhl.Items7"),
            resources.GetString("comboBoxDakhl.Items8"),
            resources.GetString("comboBoxDakhl.Items9"),
            resources.GetString("comboBoxDakhl.Items10"),
            resources.GetString("comboBoxDakhl.Items11"),
            resources.GetString("comboBoxDakhl.Items12"),
            resources.GetString("comboBoxDakhl.Items13"),
            resources.GetString("comboBoxDakhl.Items14"),
            resources.GetString("comboBoxDakhl.Items15"),
            resources.GetString("comboBoxDakhl.Items16"),
            resources.GetString("comboBoxDakhl.Items17"),
            resources.GetString("comboBoxDakhl.Items18"),
            resources.GetString("comboBoxDakhl.Items19"),
            resources.GetString("comboBoxDakhl.Items20"),
            resources.GetString("comboBoxDakhl.Items21"),
            resources.GetString("comboBoxDakhl.Items22"),
            resources.GetString("comboBoxDakhl.Items23"),
            resources.GetString("comboBoxDakhl.Items24"),
            resources.GetString("comboBoxDakhl.Items25"),
            resources.GetString("comboBoxDakhl.Items26"),
            resources.GetString("comboBoxDakhl.Items27"),
            resources.GetString("comboBoxDakhl.Items28"),
            resources.GetString("comboBoxDakhl.Items29"),
            resources.GetString("comboBoxDakhl.Items30"),
            resources.GetString("comboBoxDakhl.Items31"),
            resources.GetString("comboBoxDakhl.Items32"),
            resources.GetString("comboBoxDakhl.Items33"),
            resources.GetString("comboBoxDakhl.Items34"),
            resources.GetString("comboBoxDakhl.Items35"),
            resources.GetString("comboBoxDakhl.Items36"),
            resources.GetString("comboBoxDakhl.Items37"),
            resources.GetString("comboBoxDakhl.Items38"),
            resources.GetString("comboBoxDakhl.Items39"),
            resources.GetString("comboBoxDakhl.Items40"),
            resources.GetString("comboBoxDakhl.Items41"),
            resources.GetString("comboBoxDakhl.Items42"),
            resources.GetString("comboBoxDakhl.Items43"),
            resources.GetString("comboBoxDakhl.Items44"),
            resources.GetString("comboBoxDakhl.Items45"),
            resources.GetString("comboBoxDakhl.Items46"),
            resources.GetString("comboBoxDakhl.Items47"),
            resources.GetString("comboBoxDakhl.Items48"),
            resources.GetString("comboBoxDakhl.Items49"),
            resources.GetString("comboBoxDakhl.Items50"),
            resources.GetString("comboBoxDakhl.Items51"),
            resources.GetString("comboBoxDakhl.Items52"),
            resources.GetString("comboBoxDakhl.Items53"),
            resources.GetString("comboBoxDakhl.Items54"),
            resources.GetString("comboBoxDakhl.Items55"),
            resources.GetString("comboBoxDakhl.Items56"),
            resources.GetString("comboBoxDakhl.Items57"),
            resources.GetString("comboBoxDakhl.Items58"),
            resources.GetString("comboBoxDakhl.Items59"),
            resources.GetString("comboBoxDakhl.Items60"),
            resources.GetString("comboBoxDakhl.Items61"),
            resources.GetString("comboBoxDakhl.Items62"),
            resources.GetString("comboBoxDakhl.Items63"),
            resources.GetString("comboBoxDakhl.Items64"),
            resources.GetString("comboBoxDakhl.Items65")});
            this.comboBoxDakhl.Name = "comboBoxDakhl";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // textBoxAmountDakhl
            // 
            resources.ApplyResources(this.textBoxAmountDakhl, "textBoxAmountDakhl");
            this.textBoxAmountDakhl.Name = "textBoxAmountDakhl";
            this.textBoxAmountDakhl.Enter += new System.EventHandler(this.textBoxAmountDakhl_Enter);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // textBoxPriceDakhl
            // 
            resources.ApplyResources(this.textBoxPriceDakhl, "textBoxPriceDakhl");
            this.textBoxPriceDakhl.Name = "textBoxPriceDakhl";
            this.textBoxPriceDakhl.Enter += new System.EventHandler(this.textBoxPriceDakhl_Enter);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // buttonSaveDakhl
            // 
            resources.ApplyResources(this.buttonSaveDakhl, "buttonSaveDakhl");
            this.buttonSaveDakhl.Name = "buttonSaveDakhl";
            this.buttonSaveDakhl.UseVisualStyleBackColor = true;
            this.buttonSaveDakhl.Click += new System.EventHandler(this.buttonSaveDakhl_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel11);
            this.tabPage2.Controls.Add(this.panel10);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.dataGridViewKharj);
            this.panel11.Controls.Add(this.label2);
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.Name = "panel11";
            // 
            // dataGridViewKharj
            // 
            this.dataGridViewKharj.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewKharj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewKharj, "dataGridViewKharj");
            this.dataGridViewKharj.Name = "dataGridViewKharj";
            this.dataGridViewKharj.ReadOnly = true;
            this.dataGridViewKharj.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.comboBoxKharj);
            this.panel10.Controls.Add(this.label18);
            this.panel10.Controls.Add(this.textBoxAmountKharj);
            this.panel10.Controls.Add(this.label19);
            this.panel10.Controls.Add(this.textBoxPriceKharj);
            this.panel10.Controls.Add(this.label20);
            this.panel10.Controls.Add(this.buttonSaveKharj);
            resources.ApplyResources(this.panel10, "panel10");
            this.panel10.Name = "panel10";
            // 
            // comboBoxKharj
            // 
            this.comboBoxKharj.DropDownHeight = 250;
            resources.ApplyResources(this.comboBoxKharj, "comboBoxKharj");
            this.comboBoxKharj.FormattingEnabled = true;
            this.comboBoxKharj.Items.AddRange(new object[] {
            resources.GetString("comboBoxKharj.Items")});
            this.comboBoxKharj.Name = "comboBoxKharj";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // textBoxAmountKharj
            // 
            resources.ApplyResources(this.textBoxAmountKharj, "textBoxAmountKharj");
            this.textBoxAmountKharj.Name = "textBoxAmountKharj";
            this.textBoxAmountKharj.Enter += new System.EventHandler(this.textBoxAmountKharj_Enter);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // textBoxPriceKharj
            // 
            resources.ApplyResources(this.textBoxPriceKharj, "textBoxPriceKharj");
            this.textBoxPriceKharj.Name = "textBoxPriceKharj";
            this.textBoxPriceKharj.Enter += new System.EventHandler(this.textBoxPriceKharj_Enter);
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // buttonSaveKharj
            // 
            resources.ApplyResources(this.buttonSaveKharj, "buttonSaveKharj");
            this.buttonSaveKharj.Name = "buttonSaveKharj";
            this.buttonSaveKharj.UseVisualStyleBackColor = true;
            this.buttonSaveKharj.Click += new System.EventHandler(this.buttonSaveKharj_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel7);
            this.tabPage3.Controls.Add(this.panel6);
            this.tabPage3.Controls.Add(this.panel5);
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.dataGridViewDakhlGozaresh);
            this.panel7.Controls.Add(this.dataGridViewKharjGozaresh);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.label12);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // dataGridViewDakhlGozaresh
            // 
            this.dataGridViewDakhlGozaresh.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDakhlGozaresh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewDakhlGozaresh, "dataGridViewDakhlGozaresh");
            this.dataGridViewDakhlGozaresh.Name = "dataGridViewDakhlGozaresh";
            this.dataGridViewDakhlGozaresh.ReadOnly = true;
            this.dataGridViewDakhlGozaresh.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // dataGridViewKharjGozaresh
            // 
            this.dataGridViewKharjGozaresh.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewKharjGozaresh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewKharjGozaresh, "dataGridViewKharjGozaresh");
            this.dataGridViewKharjGozaresh.Name = "dataGridViewKharjGozaresh";
            this.dataGridViewKharjGozaresh.ReadOnly = true;
            this.dataGridViewKharjGozaresh.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label8);
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.buttonNamayeshGozaresh);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.maskedTextBoxStartDate);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.maskedTextBoxEndDate);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // buttonNamayeshGozaresh
            // 
            resources.ApplyResources(this.buttonNamayeshGozaresh, "buttonNamayeshGozaresh");
            this.buttonNamayeshGozaresh.Name = "buttonNamayeshGozaresh";
            this.buttonNamayeshGozaresh.UseVisualStyleBackColor = true;
            this.buttonNamayeshGozaresh.Click += new System.EventHandler(this.buttonNamayeshGozaresh_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // maskedTextBoxStartDate
            // 
            resources.ApplyResources(this.maskedTextBoxStartDate, "maskedTextBoxStartDate");
            this.maskedTextBoxStartDate.Name = "maskedTextBoxStartDate";
            this.maskedTextBoxStartDate.ValidatingType = typeof(System.DateTime);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // maskedTextBoxEndDate
            // 
            resources.ApplyResources(this.maskedTextBoxEndDate, "maskedTextBoxEndDate");
            this.maskedTextBoxEndDate.Name = "maskedTextBoxEndDate";
            this.maskedTextBoxEndDate.ValidatingType = typeof(System.DateTime);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Controls.Add(this.panel3);
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.buttonAddAghlamDakh);
            this.panel4.Controls.Add(this.textBoxAddAghlamDakh);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridView1, "dataGridView1");
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // buttonAddAghlamDakh
            // 
            resources.ApplyResources(this.buttonAddAghlamDakh, "buttonAddAghlamDakh");
            this.buttonAddAghlamDakh.Name = "buttonAddAghlamDakh";
            this.buttonAddAghlamDakh.UseVisualStyleBackColor = true;
            this.buttonAddAghlamDakh.Click += new System.EventHandler(this.buttonAddAghlamDakh_Click);
            // 
            // textBoxAddAghlamDakh
            // 
            resources.ApplyResources(this.textBoxAddAghlamDakh, "textBoxAddAghlamDakh");
            this.textBoxAddAghlamDakh.Name = "textBoxAddAghlamDakh";
            this.textBoxAddAghlamDakh.Enter += new System.EventHandler(this.textBoxAddAghlamDakh_Enter);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.dataGridView2);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.textBoxAddAghlamKharj);
            this.panel3.Controls.Add(this.buttonAddAghlamKharj);
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridView2, "dataGridView2");
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // textBoxAddAghlamKharj
            // 
            resources.ApplyResources(this.textBoxAddAghlamKharj, "textBoxAddAghlamKharj");
            this.textBoxAddAghlamKharj.Name = "textBoxAddAghlamKharj";
            this.textBoxAddAghlamKharj.Enter += new System.EventHandler(this.textBoxAddAghlamKharj_Enter);
            // 
            // buttonAddAghlamKharj
            // 
            resources.ApplyResources(this.buttonAddAghlamKharj, "buttonAddAghlamKharj");
            this.buttonAddAghlamKharj.Name = "buttonAddAghlamKharj";
            this.buttonAddAghlamKharj.UseVisualStyleBackColor = true;
            this.buttonAddAghlamKharj.Click += new System.EventHandler(this.buttonAddAghlamKharj_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel1);
            this.tabPage5.Controls.Add(this.button12);
            this.tabPage5.Controls.Add(this.button11);
            this.tabPage5.Controls.Add(this.button10);
            this.tabPage5.Controls.Add(this.button9);
            this.tabPage5.Controls.Add(this.button8);
            this.tabPage5.Controls.Add(this.button7);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.button1);
            resources.ApplyResources(this.tabPage5, "tabPage5");
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.labelAmoozesh);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // labelAmoozesh
            // 
            resources.ApplyResources(this.labelAmoozesh, "labelAmoozesh");
            this.labelAmoozesh.Name = "labelAmoozesh";
            // 
            // button12
            // 
            resources.ApplyResources(this.button12, "button12");
            this.button12.Name = "button12";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            resources.ApplyResources(this.button11, "button11");
            this.button11.Name = "button11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            resources.ApplyResources(this.button10, "button10");
            this.button10.Name = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button14
            // 
            this.button14.BackgroundImage = global::Hesabema.Properties.Resources.Minimize_Icon;
            resources.ApplyResources(this.button14, "button14");
            this.button14.Name = "button14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button15);
            this.panel2.Controls.Add(this.button14);
            this.panel2.Controls.Add(this.tabControl1);
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown1);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove1);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp1);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.BackgroundImage = global::Hesabema.Properties.Resources.Close_Icon;
            resources.ApplyResources(this.button15, "button15");
            this.button15.Name = "button15";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDakhl)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKharj)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDakhlGozaresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKharjGozaresh)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonSaveDakhl;
        private System.Windows.Forms.TextBox textBoxPriceDakhl;
        private System.Windows.Forms.TextBox textBoxAmountDakhl;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridViewDakhl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewKharj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSaveKharj;
        private System.Windows.Forms.TextBox textBoxPriceKharj;
        private System.Windows.Forms.TextBox textBoxAmountKharj;
        private System.Windows.Forms.ComboBox comboBoxKharj;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxStartDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridViewKharjGozaresh;
        private System.Windows.Forms.DataGridView dataGridViewDakhlGozaresh;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEndDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonNamayeshGozaresh;
        public System.Windows.Forms.ComboBox comboBoxDakhl;
        private System.Windows.Forms.Button buttonAddAghlamKharj;
        private System.Windows.Forms.TextBox textBoxAddAghlamKharj;
        private System.Windows.Forms.Button buttonAddAghlamDakh;
        private System.Windows.Forms.TextBox textBoxAddAghlamDakh;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label labelAmoozesh;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
    }
}

