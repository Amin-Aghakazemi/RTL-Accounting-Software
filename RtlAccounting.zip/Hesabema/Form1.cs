﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessEntity;
using BusinessLogicLayer;
using System.Data.Entity;
using System.Globalization;
using MD.PersianDateTime;
using System.Data.SqlClient;




namespace Hesabema
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();
        }

        // This application was developed from scratch by Amin Aghakazemi and published on GitHub under the MIT license.

        //Form_Load Event
        #region
        private void Form1_Load(object sender, EventArgs e)
        {


            Bldakhl bldakhl2 = new Bldakhl();
            List<Dakhl> dakhllist3 = bldakhl2.ReadDakhl();
            if (dakhllist3.Count() > 0)
            {
                dataGridViewDakhl.DataSource = dakhllist3;
            }


            Blkharj blkharj2 = new Blkharj();
            List<Kharj> kharjlist3 = blkharj2.Readkharj();
            if (kharjlist3.Count() > 0)
            {
                dataGridViewKharj.DataSource = kharjlist3;
            }





            Blentitydakhl blentitydakhl2 = new Blentitydakhl();
            List<EntityDakhl> entitydakhllist3 = blentitydakhl2.Readentitydakhl();
            if (entitydakhllist3.Count() > 0)
            {
                dataGridView1.DataSource = entitydakhllist3;


                var qdakhl = from i in entitydakhllist3 select i.name;
                namesBindingSource.DataSource = qdakhl;
                comboBoxDakhl.DataSource = namesBindingSource;

            }


            Blentitykharj blentitykharj2 = new Blentitykharj();
            List<EntityKharj> entitykharjlist3 = blentitykharj2.Readentitykharj();
            if (entitykharjlist3.Count() > 0)
            {
                dataGridView2.DataSource = entitykharjlist3;

                var qkharj = from i in entitykharjlist3 select i.name;
                namesBindingSource2.DataSource = qkharj;
                comboBoxKharj.DataSource = namesBindingSource2;
            }





            maskedTextBoxStartDate.Text = DateShamsiOneWeekErlier();
            maskedTextBoxEndDate.Text = DateShamsi();


            Bldakhl bldakhl6 = new Bldakhl();
            List<Dakhl> dakhllist6 = bldakhl6.ReadDakhl();
            if (dakhllist6.Count() > 0)
            {
                NamayeshGozareshDakhl();
                SumDakhls();
                Sood();
                Zarar();
            }


            Blkharj blkharj5 = new Blkharj();
            List<Kharj> kharjlist5 = blkharj5.Readkharj();
            if (kharjlist5.Count() > 0)
            {
                NamayeshGozareshKharj();
                SumKharjs();
                Sood();
                Zarar();
            }
        }
        #endregion




        //Close and Minimize Buttons
        #region
        private void button14_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion




        //Make a Borderless Form Movable
        #region
        private bool mouseDown1;
        private Point lastLocation1;

        private void Form1_MouseDown1(object sender, MouseEventArgs e)
        {
            mouseDown1 = true;
            lastLocation1 = e.Location;
        }

        private void Form1_MouseMove1(object sender, MouseEventArgs e)
        {
            if (mouseDown1)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation1.X) + e.X, (this.Location.Y - lastLocation1.Y) + e.Y);

                this.Update();
            }
        }

        private void Form1_MouseUp1(object sender, MouseEventArgs e)
        {
            mouseDown1 = false;
        }
        #endregion




        //Gozaresh Page Functions ---> Gozaresh tab
        #region


        //تعریف افعال
        public int SumDakhls()
        {
            int sum = 0;
            for (int i = 0; i < dataGridViewDakhlGozaresh.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridViewDakhlGozaresh.Rows[i].Cells[3].Value);
            }
            label9.Text = sum.ToString() + " تومان";
            return sum;
        }

        public int SumKharjs()
        {
            int sum = 0;
            for (int i = 0; i < dataGridViewKharjGozaresh.Rows.Count; ++i)
            {
                sum += Convert.ToInt32(dataGridViewKharjGozaresh.Rows[i].Cells[3].Value);
            }
            label11.Text = sum.ToString() + " تومان";
            return sum;
        }


        public int Sood()
        {
            Bldakhl bldakhl7 = new Bldakhl();
            List<Dakhl> dakhllist7 = bldakhl7.ReadDakhl();
            Blkharj blkharj7 = new Blkharj();
            List<Kharj> kharjlist7 = blkharj7.Readkharj();
            int sood = SumDakhls() - SumKharjs();
            if (dakhllist7.Count() > 0 && kharjlist7.Count() > 0 && sood > 0)
            {
                label7.Text = sood.ToString() + " تومان";
            }
            else if (dakhllist7.Count() > 0 && kharjlist7.Count() > 0 && sood <= 0)
            {
                label7.Text = "سود نداریم";
            }
            return sood;
        }

        public int Zarar()
        {
            Bldakhl bldakhl7 = new Bldakhl();
            List<Dakhl> dakhllist7 = bldakhl7.ReadDakhl();
            Blkharj blkharj7 = new Blkharj();
            List<Kharj> kharjlist7 = blkharj7.Readkharj();
            int zarar = SumDakhls() - SumKharjs();

            if (Sood() >= 0 && dakhllist7.Count() > 0 && kharjlist7.Count() > 0)
            {
                label8.Text = "ضرر نداریم";
            }
            else if (dakhllist7.Count() > 0 && kharjlist7.Count() > 0)
            {
                label8.Text = zarar.ToString() + " تومان";
            }
            return zarar;
        }



        public void NamayeshGozareshDakhl()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=hesabema;Integrated Security=true");
            SqlCommand cmd = new SqlCommand();
            //cmd.CommandText = "select * from Dakhls where date BETWEEN @data1 and @data2";
            cmd.CommandText = "select * from Dakhls where date >= @data1 AND date <= @data2";
            cmd.Parameters.Add("@data1", SqlDbType.NVarChar).Value = maskedTextBoxStartDate.Text;
            cmd.Parameters.Add("@data2", SqlDbType.NVarChar).Value = maskedTextBoxEndDate.Text;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridViewDakhlGozaresh.DataSource = dt;
        }

        public void NamayeshGozareshKharj()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=hesabema;Integrated Security=true");
            SqlCommand cmd = new SqlCommand();
            //cmd.CommandText = "select * from Kharjs where date BETWEEN @data1 and @data2";
            cmd.CommandText = "select * from Kharjs where date >= @data1 AND date <= @data2";
            cmd.Parameters.Add("@data1", SqlDbType.NVarChar).Value = maskedTextBoxStartDate.Text;
            cmd.Parameters.Add("@data2", SqlDbType.NVarChar).Value = maskedTextBoxEndDate.Text;
            cmd.Connection = con;
            SqlDataAdapter dakharj = new SqlDataAdapter(cmd);
            DataTable dtkharj = new DataTable();
            dakharj.Fill(dtkharj);
            dataGridViewKharjGozaresh.DataSource = dtkharj;
        }


        //اجرای افعال
        private void buttonNamayeshGozaresh_Click(object sender, EventArgs e)
        {
            NamayeshGozareshDakhl();

            NamayeshGozareshKharj();

            Sood();

            Zarar();
        }
        #endregion




        //Buttons Add to Database ---> Dakhl & Kharj tabs
        #region


        //تعریف ملزومات
        public static string DateShamsi()
        {
            var currentDate = DateTime.Now;
            PersianCalendar pcCalender = new PersianCalendar();

            int year = pcCalender.GetYear(currentDate);
            int month = pcCalender.GetMonth(currentDate);
            int day = pcCalender.GetDayOfMonth(currentDate);

            string shamsiDate = string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(year + "/" + month + "/" + day));
            return shamsiDate;
        }

        public static string DateShamsiOneWeekErlier()
        {
            var currentDate2 = DateTime.Now;
            PersianCalendar pcCalender2 = new PersianCalendar();

            int year = pcCalender2.GetYear(currentDate2);
            int month = pcCalender2.GetMonth(currentDate2);
            int day = pcCalender2.GetDayOfMonth(currentDate2.Date.AddDays(-7));

            string shamsiDate = string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(year + "/" + month + "/" + day));
            return shamsiDate;
        }



        //تعرف افعال
        public string Create(Dakhl dakhl)
        {
            Bldakhl bldakhl = new Bldakhl();
            return bldakhl.Create(dakhl);
        }

        public string Create(Kharj kharj)
        {
            Blkharj blkharj = new Blkharj();
            return blkharj.Create(kharj);
        }



        //اجرای افعال
        private void buttonSaveDakhl_Click(object sender, EventArgs e)
        {
            Create(new Dakhl { name = comboBoxDakhl.SelectedItem.ToString(), amount = int.Parse(textBoxAmountDakhl.Text), price = int.Parse(textBoxPriceDakhl.Text) , date=DateShamsi() } );
            Bldakhl bldakhl2 = new Bldakhl();
            List<Dakhl> dakhllist3 = bldakhl2.ReadDakhl();
            dataGridViewDakhl.DataSource = null;
            dataGridViewDakhl.DataSource = dakhllist3;
            
        }



        private void buttonSaveKharj_Click(object sender, EventArgs e)
        {
            Create(new Kharj { name = comboBoxKharj.SelectedItem.ToString(), amount = int.Parse(textBoxAmountKharj.Text), price = int.Parse(textBoxPriceKharj.Text), date = DateShamsi() });
            Blkharj blkharj2 = new Blkharj();
            List<Kharj> kharjlist3 = blkharj2.Readkharj();
            dataGridViewKharj.DataSource = null;
            dataGridViewKharj.DataSource = kharjlist3;

        }
        #endregion




        //Buttons Adding Aghlam ---> Tanzimat tab
        #region

        BindingSource namesBindingSource = new BindingSource();
        BindingSource namesBindingSource2 = new BindingSource();

        //تعریف افعال
        public string Create(EntityDakhl entitydakhl)
        {
            Blentitydakhl blentitydakhl = new Blentitydakhl();
            return blentitydakhl.Create(entitydakhl);
        }

        public string Create(EntityKharj entitykharj)
        {
            Blentitykharj blentitykharj = new Blentitykharj();
            return blentitykharj.Create(entitykharj);
        }

        //اجرای افعال
        private void buttonAddAghlamDakh_Click(object sender, EventArgs e)
        {
            Create(new EntityDakhl { name = textBoxAddAghlamDakh.Text});
            Blentitydakhl blentitydakhl2 = new Blentitydakhl();
            List<EntityDakhl> entitydakhllist3 = blentitydakhl2.Readentitydakhl();
            dataGridView1.DataSource = null;
            if (entitydakhllist3.Count() > 0)
            {
                dataGridView1.DataSource = entitydakhllist3;

                var qdakhl = from i in entitydakhllist3 select i.name;
                namesBindingSource.DataSource = null;
                namesBindingSource.DataSource = qdakhl;
                comboBoxDakhl.DataSource = null;
                comboBoxDakhl.DataSource = namesBindingSource;

            }
        }

        
        private void buttonAddAghlamKharj_Click(object sender, EventArgs e)
        {
            Create(new EntityKharj { name = textBoxAddAghlamKharj.Text });
            Blentitykharj blentitykharj2 = new Blentitykharj();
            List<EntityKharj> entitykharjlist3 = blentitykharj2.Readentitykharj();
            dataGridView2.DataSource = null;
            if (entitykharjlist3.Count() > 0)
            {
                dataGridView2.DataSource = entitykharjlist3;

                var qkharj = from i in entitykharjlist3 select i.name;
                namesBindingSource2.DataSource = null;
                namesBindingSource2.DataSource = qkharj;
                comboBoxKharj.DataSource = null;
                comboBoxKharj.DataSource = namesBindingSource2;

            }
        }
        #endregion




        //Clear Textboxes ---> Dakhl & Kharj & Tanzimat tabs
        #region
        private void textBoxAddAghlamDakh_Enter(object sender, EventArgs e)
        {
            textBoxAddAghlamDakh.Clear();
            textBoxAddAghlamDakh.Text = @"_____ (___)";
        }

        private void textBoxAddAghlamKharj_Enter(object sender, EventArgs e)
        {
            textBoxAddAghlamKharj.Clear();
            textBoxAddAghlamKharj.Text = @"_____ (___)";
        }

        private void textBoxAmountKharj_Enter(object sender, EventArgs e)
        {
            textBoxAmountKharj.Clear();
        }

        private void textBoxPriceKharj_Enter(object sender, EventArgs e)
        {
            textBoxPriceKharj.Clear();
        }

        private void textBoxAmountDakhl_Enter(object sender, EventArgs e)
        {
            textBoxAmountDakhl.Clear();
        }

        private void textBoxPriceDakhl_Enter(object sender, EventArgs e)
        {
            textBoxPriceDakhl.Clear();
        }
        #endregion




        //Amoozesh Buttons ---> Amoozesh tab
        #region
        private void button1_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بسیبسیبسی یبلیب یبلی بر روی دکمه اول نمایش داده می شود" +
                "\n" +
                "در خط بعدی بعد از بک اسلش و ان ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود.";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود" +
                "\n" +
                "در خط بعدی بعد از بک اسلش و ان ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود ... این متن پس از کلیک کردن بر روی دکمه اول نمایش داده می شود.";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه سوم نمایش داده می شود";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه چهارم نمایش داده می شود";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه پنجم نمایش داده می شود";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه ششم نمایش داده می شود";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه هفتم نمایش داده می شود";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه هشتم نمایش داده می شود";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه نهم نمایش داده می شود";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه دهم نمایش داده می شود";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه یازدهم نمایش داده می شود";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            labelAmoozesh.Text = "این متن پس از کلیک کردن بر روی دکمه دوازدهم نمایش داده می شود";
        }






        #endregion

       
    }
}
