﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntity;
using System.Data.Entity;

namespace DataAccessLayer
{

    public class Dldakhl
    {
        public string Create(Dakhl dakhl)
        {
            Database db1 = new Database();
            db1.Dakhls.Add(dakhl);
            db1.SaveChanges();
            //var q = from i in db1.Dakhls select i;
            //dakhllist.Add(q);
            
            return "با موفقیت ذخیره شد";
        }

        public List<Dakhl> ReadDakhl()
        {
            Database db2 = new Database();
            List<Dakhl> dakhllist = db2.Dakhls.ToList();

            return dakhllist;
        }

    }

    



    public class Dlkharj
    {
        public string Create(Kharj kharj)
        {
            Database db3 = new Database();
            db3.Kharjs.Add(kharj);
            db3.SaveChanges();
            return "با موفقیت ذخیره شد";
        }

        public List<Kharj> ReadKharj()
        {
            Database db4 = new Database();
            List<Kharj> kharjlist = db4.Kharjs.ToList();

            return kharjlist;
        }
    }





    public class Dlentitydakhl
    {
        public string Create(EntityDakhl entitydakhl)
        {
            Database db8 = new Database();
            db8.entitydakhls.Add(entitydakhl);
            db8.SaveChanges();
            return "با موفقیت ذخیره شد";
        }

        public List<EntityDakhl> Readentitydakhl()
        {
            Database db8 = new Database();
            List<EntityDakhl> entitydakhllist = db8.entitydakhls.ToList();

            return entitydakhllist;
        }
    }





    public class Dlentitykharj
    {
        public string Create(EntityKharj entitykharj)
        {
            Database db9 = new Database();
            db9.entitykharjs.Add(entitykharj);
            db9.SaveChanges();
            return "با موفقیت ذخیره شد";
        }

        public List<EntityKharj> Readentitykharj()
        {
            Database db9 = new Database();
            List<EntityKharj> entitykharjlist = db9.entitykharjs.ToList();

            return entitykharjlist;
        }
    }


}
