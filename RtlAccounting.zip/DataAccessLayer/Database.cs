﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using BusinessEntity;

namespace DataAccessLayer
{
    class Database : DbContext
    {
        public Database() : base ("name=constr") { }

        public DbSet<Dakhl> Dakhls { set; get; }
        public DbSet<Kharj> Kharjs { set; get; }
        public DbSet<EntityDakhl> entitydakhls { set; get; }
        public DbSet<EntityKharj> entitykharjs { set; get; }


    }
}
